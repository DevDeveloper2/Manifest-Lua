addappid(40)
addappid(41,1,"025b3eca6aed746732da1e3669452167afa6df93a4a732f76f82776d63c11661")
setManifestid(41,"2010889186716175170",0)
addappid(42,1,"dbf1cb61d0e85bc273f75e5783379604a9535d51d890ba3ac4bf33a3179e5d1b")
setManifestid(42,"6706743008656511400",0)
addappid(43,1,"aa98bee53ed3ef9af322ce948ccb6d047ffb1db406454f26bc1cd4c00f524059")
setManifestid(43,"7539779087273614326",0)
addappid(44,1,"60eddbf739a2d595b66ba0bda767de73f05fb962e93aa5028f697532a9e99c8d")
setManifestid(44,"2527015534741255929",0)
addappid(45,1,"219e96e5fd5ef98d939303b989c41d8a4fc282923f4ba5c2626f689b709b623f")
setManifestid(45,"281708254088077590",0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]