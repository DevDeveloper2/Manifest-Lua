addappid(20)
addappid(21,1,"5e65afcc360e7a91ccb619a2844343f1fb812d08c0bec737dd8312bde44f2bf0")
setManifestid(21,"7841127166138118042",0)
addappid(22,1,"5228e244ad14903dc8ae46ae97b1a5e60932b0f57b2450f0f3b016467fc2cf09")
setManifestid(22,"3314961887333137053",0)
addappid(23,1,"9f76dddac9888b5e5491aaea81b5f37bfdc947e07bddba6a3026bbeac820b140")
setManifestid(23,"2879882074779232341",0)
addappid(24,1,"a2ad6af5fe758c7c1323fec5b5b801c3853cf4a14707f40c0d52f378991c771e")
setManifestid(24,"2190082753677736743",0)
addappid(25,1,"6f7dc748668fa80cd5883536d5396365393b35fc68f35b8dea74e7fab959d57c")
setManifestid(25,"2265638006490284094",0)

--[[
This file Generated using fares.top Website 
-----> join discord Server : https://discord.gg/steamgames 
]]